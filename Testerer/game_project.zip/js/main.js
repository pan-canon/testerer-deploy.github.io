// Регистрация Service Worker
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("js/serviceWorker.js")
    .then(() => console.log("Service Worker зарегистрирован!"))
    .catch((error) => console.log("Ошибка при регистрации SW:", error));
}

// Настройка локализации
let currentLang = localStorage.getItem("lang") || navigator.language.slice(0, 2);
fetch("locales/locales.json")
  .then(response => response.json())
  .then(data => {
    updateLanguage(data, currentLang);
  });

document.querySelector("#language-selector")?.addEventListener("change", (event) => {
  currentLang = event.target.value;
  localStorage.setItem("lang", currentLang);
  fetch("locales/locales.json")
    .then(response => response.json())
    .then(data => updateLanguage(data, currentLang));
});

function updateLanguage(data, lang) {
  document.querySelectorAll("[data-i18n]").forEach(el => {
    el.textContent = data[lang][el.dataset.i18n] || el.textContent;
  });
}

// Настройка персонажа
document.querySelector("#start-btn").addEventListener("click", () => {
  document.querySelector("#setup-screen").style.display = "none";
  document.querySelector("#main-screen").style.display = "block";
  localStorage.setItem("playerName", document.querySelector("#player-name").value);
  localStorage.setItem("playerGender", document.querySelector("#player-gender").value);
});

// Настройка камеры
document.addEventListener("DOMContentLoaded", () => {
  const video = document.querySelector("#camera-feed");
  const captureBtn = document.querySelector("#capture-btn");
  const canvas = document.querySelector("#snapshot");
  const context = canvas.getContext("2d");
  const savedPhoto = document.querySelector("#saved-photo");

  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    navigator.mediaDevices.getUserMedia({ video: true })
      .then((stream) => {
        video.srcObject = stream;
      })
      .catch((err) => console.log("Ошибка при доступе к камере:", err));
  }

  captureBtn.addEventListener("click", () => {
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    const imageData = canvas.toDataURL("image/png");
    localStorage.setItem("playerPhoto", imageData);
    savedPhoto.src = imageData;
    savedPhoto.style.display = "block";
    console.log("Фото сохранено");
  });

  const storedPhoto = localStorage.getItem("playerPhoto");
  if (storedPhoto) {
    savedPhoto.src = storedPhoto;
    savedPhoto.style.display = "block";
  }
});
