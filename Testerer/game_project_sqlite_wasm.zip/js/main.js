document.addEventListener("DOMContentLoaded", async () => {
  console.log("Приложение загружено");

  let db = null;
  initDatabase();

  async function initDatabase() {
    try {
      const SQL = await initSqlJs({ locateFile: filename => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.8.0/${filename}` });
      db = new SQL.Database();
      db.run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT, gender TEXT, photo TEXT, language TEXT);");
      console.log("База данных SQLite инициализирована");
    } catch (error) {
      console.error("Ошибка инициализации SQLite:", error);
    }
  }

  document.querySelector("#complete-registration").addEventListener("click", () => {
    const playerName = document.querySelector("#player-name").value;
    const playerGender = document.querySelector("#player-gender").value;
    const selectedLang = document.querySelector("#language-selector").value;
    const storedPhoto = document.querySelector("#saved-selfie").src;

    if (!playerName || !storedPhoto) {
      alert("Введите имя и сделайте селфи!");
      return;
    }

    db.run("INSERT INTO users (name, gender, photo, language) VALUES (?, ?, ?, ?);", [playerName, playerGender, storedPhoto, selectedLang]);
    console.log("Данные сохранены в SQLite");

    document.querySelector("#setup-screen").style.display = "none";
    document.querySelector("#photo-step").style.display = "none";
    document.querySelector("#main-screen").style.display = "block";
  });
});

// Регистрация Service Worker
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("/js/serviceWorker.js")
    .then(() => console.log("Service Worker зарегистрирован!"))
    .catch((error) => console.log("Ошибка при регистрации SW:", error));
}
