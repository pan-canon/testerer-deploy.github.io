// Заглушка для sql-wasm.js
console.log("SQLite WebAssembly загружен (sql-wasm.js)");
