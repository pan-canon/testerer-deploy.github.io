const db = new Promise((resolve, reject) => {
  const request = indexedDB.open("gameDB", 1);

  request.onupgradeneeded = event => {
    const db = event.target.result;
    db.createObjectStore("playerData", { keyPath: "id" });
  };

  request.onsuccess = event => {
    resolve(event.target.result);
  };

  request.onerror = event => {
    reject(event.target.error);
  };
});

async function saveData(data) {
  const database = await db;
  const transaction = database.transaction("playerData", "readwrite");
  const store = transaction.objectStore("playerData");
  store.put({ id: 1, ...data });
}

async function loadData() {
  const database = await db;
  return new Promise(resolve => {
    const transaction = database.transaction("playerData", "readonly");
    const store = transaction.objectStore("playerData");
    const request = store.get(1);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => resolve(null);
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  const data = await loadData();
  if (data) {
    document.querySelector("#profile-name").textContent = data.playerName;
    document.querySelector("#profile-photo").src = data.playerPhoto || "";
    document.querySelector("#profile-photo").style.display = data.playerPhoto ? "block" : "none";
  }

  document.querySelector("#start-btn").addEventListener("click", async () => {
    const playerName = document.querySelector("#player-name").value;
    const playerGender = document.querySelector("#player-gender").value;
    const selectedLang = document.querySelector("#language-selector").value;

    if (!playerName) {
      alert("Please enter your name");
      return;
    }

    await saveData({ playerName, playerGender, selectedLang });

    document.querySelector("#setup-screen").style.display = "none";
    document.querySelector("#main-screen").style.display = "block";
  });

  document.querySelector("#reset-btn").addEventListener("click", async () => {
    const database = await db;
    const transaction = database.transaction("playerData", "readwrite");
    const store = transaction.objectStore("playerData");
    store.clear();
    location.reload();
  });
});
